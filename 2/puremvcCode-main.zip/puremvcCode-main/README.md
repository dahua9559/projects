# puremvc源码查看



#### [框架基础设计入门](https://github.com/sanzhixiong1986/puremvcCode/blob/main/README1.md)

#### [初始化Command](https://github.com/sanzhixiong1986/puremvcCode/blob/main/README2.md)

[Proxy基础](https://github.com/sanzhixiong1986/puremvcCode/blob/main/README3.md)

[Model基础](https://github.com/sanzhixiong1986/puremvcCode/blob/main/README4.md)

[Mediator基础](https://github.com/sanzhixiong1986/puremvcCode/blob/main/README5.md)

[Mediator应用](https://github.com/sanzhixiong1986/puremvcCode/blob/main/README6.md)
