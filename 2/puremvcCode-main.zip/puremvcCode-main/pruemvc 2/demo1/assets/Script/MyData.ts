//数值类
export default class MyData{
    public Level:number = 0;
}